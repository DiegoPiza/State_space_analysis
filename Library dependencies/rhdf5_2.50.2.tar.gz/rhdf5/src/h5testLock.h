#include <fcntl.h>
#include "myhdf5.h"
#include <H5private.h>

SEXP _h5fileLock(SEXP _file_name);
